@extends('master')
@section('title')
    Admin
@endsection
